//
// Created by petrsejvl on 22.04.20.
//

#include "log.h"
