//
// Created by petrsejvl on 22.04.20.
//

#include "request.h"

size_t Request::_id = 0;