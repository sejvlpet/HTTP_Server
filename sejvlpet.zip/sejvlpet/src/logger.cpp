#include "logger.h"

Logger::Logger(std::string format) : _format(std::move(format)) {}
