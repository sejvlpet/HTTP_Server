#To run tests, compile those source files

Hello world
    *prints hello world to console*
    
Test bye
    *sends request to localhost:8080/bye.html and compares result with expected*
    
Test invalid request
    *sends request with invalid header and expects to recieve 500*